/* ==========================================================
   STORE SETTINGS + PRODUCT LIST
   Naye products yahin add/edit karo. Baaki site automatic update hogi.
   ========================================================== */

const STORE = {
    currency: "₹",
    // WhatsApp number country code ke saath, bina + ya space ke. Example: "919876543210"
    whatsapp: "",
    // Apni email (optional)
    email: ""
};

/*
  Har product me:
  id        : unique chhota naam (spaces nahi)
  title     : product ka naam
  category  : filter ke liye (e.g. "Guides", "Templates", "Presets")
  price     : number (e.g. 199)
  oldPrice  : (optional) cut hua purana price
  emoji     : image na ho to ye dikhega
  image     : (optional) "assets/product1.jpg" jaisa path
  badge     : (optional) "New", "Bestseller"
  short     : card pe chhota description
  description : detail page ka description
  features  : bullet points ki list
  buyUrl    : Razorpay Payment Link / Gumroad / Instamojo ka link.
              Khali chhodo to "Buy Now" WhatsApp/contact pe le jayega.
*/

const PRODUCTS = [
    {
        id: "creator-starter-guide",
        title: "Content Creator Starter Guide 2026",
        category: "Guides",
        price: 199,
        oldPrice: 499,
        emoji: "📘",
        badge: "Bestseller",
        short: "Zero se YouTube channel shuru karne ka step-by-step guide.",
        description: "Ye sample product hai. Yahan apne guide ka poora description likho: kis ke liye hai, kya seekhne ko milega aur kaise use kare.",
        features: [
            "Channel setup se pehle video tak ka full roadmap",
            "Niche selection aur content ideas",
            "Thumbnail aur title ke simple rules",
            "Instant digital download (PDF)"
        ],
        buyUrl: ""
    },
    {
        id: "ai-tools-cheatsheet",
        title: "Top AI Tools Cheat Sheet",
        category: "Guides",
        price: 99,
        emoji: "🤖",
        badge: "New",
        short: "Daily kaam ke liye best AI tools ki ready-to-use list.",
        description: "Ye sample product hai. Yahan batao ki is cheat sheet me kaun se AI tools aur unke use cases hain.",
        features: [
            "Writing, design aur video ke liye AI tools",
            "Har tool ka use case aur tips",
            "Time bachane wale prompts",
            "Instant digital download (PDF)"
        ],
        buyUrl: ""
    },
    {
        id: "video-editing-presets",
        title: "Video Editing Presets Pack",
        category: "Presets",
        price: 299,
        oldPrice: 599,
        emoji: "🎬",
        short: "Apne videos ko professional look dene ke liye presets.",
        description: "Ye sample product hai. Yahan batao ki presets kis software ke liye hain (CapCut, Premiere Pro etc.).",
        features: [
            "Ready-to-use color presets",
            "Transitions aur text styles",
            "Beginner friendly, drag and drop",
            "Instant digital download"
        ],
        buyUrl: ""
    },
    {
        id: "shorts-growth-checklist",
        title: "YouTube Shorts Growth Checklist",
        category: "Templates",
        price: 149,
        emoji: "📈",
        short: "Shorts par views badhane ka simple checklist.",
        description: "Ye sample product hai. Yahan apne checklist ke baare me likho.",
        features: [
            "Hook, editing aur posting checklist",
            "Weekly posting planner",
            "Common mistakes jo avoid karni hain",
            "Instant digital download (PDF)"
        ],
        buyUrl: ""
    },
    {
        id: "content-calendar",
        title: "30 Day Content Calendar Template",
        category: "Templates",
        price: 129,
        emoji: "🗓️",
        short: "30 din ka content plan, ready template ke saath.",
        description: "Ye sample product hai. Yahan template ka format (Notion, Excel, PDF) aur use batao.",
        features: [
            "30 din ka posting plan",
            "Idea tracker aur status board",
            "Edit karne layak template",
            "Instant digital download"
        ],
        buyUrl: ""
    },
    {
        id: "creator-bundle",
        title: "Complete Creator Bundle",
        category: "Bundles",
        price: 499,
        oldPrice: 1075,
        emoji: "🎁",
        badge: "Best Value",
        short: "Saare guides, presets aur templates ek saath, bachat ke saath.",
        description: "Ye sample product hai. Bundle me kya kya milta hai yahan likho.",
        features: [
            "Starter Guide + AI Tools Cheat Sheet",
            "Video Editing Presets Pack",
            "Shorts Checklist + Content Calendar",
            "Sab kuch ek hi payment me"
        ],
        buyUrl: ""
    }
];
