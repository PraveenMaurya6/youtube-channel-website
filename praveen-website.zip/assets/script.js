/* ==========================================================
   Shared behaviour: nav, page transitions, scroll reveal,
   product rendering (shop, home featured, product detail)
   ========================================================== */

(function () {
    "use strict";

    var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    /* ---------- Helpers ---------- */

    function money(n) {
        return STORE.currency + Number(n).toLocaleString("en-IN");
    }

    function esc(s) {
        return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
    }

    function validWhatsapp() {
        return /^\d{10,15}$/.test(STORE.whatsapp || "");
    }

    // Buy button destination: payment link > WhatsApp > email > contact section
    function buyLink(p) {
        if (p.buyUrl) return { href: p.buyUrl, external: true };
        var msg = "Hi, I want to buy: " + p.title + " (" + money(p.price) + ")";
        if (validWhatsapp()) {
            return { href: "https://wa.me/" + STORE.whatsapp + "?text=" + encodeURIComponent(msg), external: true };
        }
        if (STORE.email) {
            return { href: "mailto:" + STORE.email + "?subject=" + encodeURIComponent("Order: " + p.title) + "&body=" + encodeURIComponent(msg), external: false };
        }
        return { href: "index.html#contact", external: false };
    }

    function visual(p) {
        var inner = p.image
            ? '<img src="' + esc(p.image) + '" alt="' + esc(p.title) + '" loading="lazy">'
            : '<span class="emoji">' + esc(p.emoji || "🛍️") + "</span>";
        var badge = p.badge ? '<span class="badge">' + esc(p.badge) + "</span>" : "";
        return '<div class="product-visual">' + badge + inner + "</div>";
    }

    function priceHtml(p) {
        return '<div class="price">' + money(p.price) +
            (p.oldPrice ? "<small>" + money(p.oldPrice) + "</small>" : "") + "</div>";
    }

    function card(p, i) {
        return '<a class="product-card reveal" data-delay="' + (i % 3 + 1) + '" href="product.html?id=' + encodeURIComponent(p.id) + '">' +
            visual(p) +
            '<div class="product-body">' +
            '<span class="product-cat">' + esc(p.category) + "</span>" +
            "<h3>" + esc(p.title) + "</h3>" +
            "<p>" + esc(p.short) + "</p>" +
            '<div class="product-foot">' + priceHtml(p) + '<span class="view-link">View →</span></div>' +
            "</div></a>";
    }

    /* ---------- Navigation ---------- */

    function initNav() {
        var toggle = document.querySelector(".nav-toggle");
        var links = document.querySelector(".nav-links");
        if (!toggle || !links) return;

        toggle.addEventListener("click", function () {
            var open = links.classList.toggle("open");
            toggle.classList.toggle("open", open);
            toggle.setAttribute("aria-expanded", open);
        });
        links.addEventListener("click", function (e) {
            if (e.target.tagName === "A") {
                links.classList.remove("open");
                toggle.classList.remove("open");
            }
        });
    }

    /* ---------- Smooth page transitions ---------- */

    function initTransitions() {
        document.addEventListener("click", function (e) {
            if (reduceMotion || e.defaultPrevented || e.button !== 0) return;
            if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

            var a = e.target.closest("a");
            if (!a || !a.href || a.target === "_blank" || a.hasAttribute("download")) return;

            var url = new URL(a.href, location.href);
            if (url.origin !== location.origin) return;                                   // external
            if (url.pathname === location.pathname && url.search === location.search) return; // same page / hash only

            e.preventDefault();
            document.body.classList.add("leaving");
            setTimeout(function () { location.href = url.href; }, 280);
        });

        // Back button (bfcache) should not stay faded out
        window.addEventListener("pageshow", function () {
            document.body.classList.remove("leaving");
        });
    }

    /* ---------- Scroll reveal ---------- */

    var observer = null;

    function initReveal() {
        if (!("IntersectionObserver" in window)) {
            document.querySelectorAll(".reveal").forEach(function (el) { el.classList.add("in"); });
            return;
        }
        observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    en.target.classList.add("in");
                    observer.unobserve(en.target);
                }
            });
        }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
        observeNew();
    }

    function observeNew() {
        document.querySelectorAll(".reveal:not(.in)").forEach(function (el) {
            if (observer) observer.observe(el); else el.classList.add("in");
        });
    }

    /* ---------- Featured products (home) ---------- */

    function renderFeatured() {
        var box = document.getElementById("featuredGrid");
        if (!box || typeof PRODUCTS === "undefined") return;
        box.innerHTML = PRODUCTS.slice(0, 3).map(card).join("");
    }

    /* ---------- Shop page ---------- */

    function renderShop() {
        var grid = document.getElementById("productGrid");
        if (!grid || typeof PRODUCTS === "undefined") return;

        var chipsBox = document.getElementById("filters");
        var search = document.getElementById("search");
        var active = "All";

        var cats = ["All"];
        PRODUCTS.forEach(function (p) { if (cats.indexOf(p.category) < 0) cats.push(p.category); });

        chipsBox.innerHTML = cats.map(function (c) {
            return '<button class="chip' + (c === "All" ? " active" : "") + '" data-cat="' + esc(c) + '">' + esc(c) + "</button>";
        }).join("");

        function draw() {
            var q = (search.value || "").toLowerCase().trim();
            var list = PRODUCTS.filter(function (p) {
                var okCat = active === "All" || p.category === active;
                var okQ = !q || (p.title + " " + p.short + " " + p.category).toLowerCase().indexOf(q) > -1;
                return okCat && okQ;
            });
            grid.innerHTML = list.length
                ? list.map(card).join("")
                : '<p class="empty">Koi product nahi mila. Kuch aur search karke dekho.</p>';
            observeNew();
        }

        chipsBox.addEventListener("click", function (e) {
            var b = e.target.closest(".chip");
            if (!b) return;
            active = b.getAttribute("data-cat");
            chipsBox.querySelectorAll(".chip").forEach(function (c) { c.classList.toggle("active", c === b); });
            draw();
        });
        search.addEventListener("input", draw);
        draw();
    }

    /* ---------- Product detail page ---------- */

    function renderDetail() {
        var box = document.getElementById("productDetail");
        if (!box || typeof PRODUCTS === "undefined") return;

        var id = new URLSearchParams(location.search).get("id");
        var p = PRODUCTS.filter(function (x) { return x.id === id; })[0];

        if (!p) {
            box.innerHTML = '<div class="empty"><h2>Product nahi mila</h2><p>Ye link galat ya purana ho sakta hai.</p>' +
                '<a class="btn" href="shop.html">← Shop par wapas jao</a></div>';
            return;
        }

        document.title = p.title + " | Praveen Maurya";
        var crumb = document.getElementById("crumbName");
        if (crumb) crumb.textContent = p.title;

        var b = buyLink(p);
        var ext = b.external ? ' target="_blank" rel="noopener"' : "";

        box.innerHTML =
            '<div class="reveal">' + visual(p) + "</div>" +
            '<div class="reveal" data-delay="1">' +
            '<span class="product-cat">' + esc(p.category) + "</span>" +
            "<h1>" + esc(p.title) + "</h1>" +
            priceHtml(p) +
            '<p class="desc">' + esc(p.description) + "</p>" +
            '<ul class="features">' + (p.features || []).map(function (f) { return "<li>" + esc(f) + "</li>"; }).join("") + "</ul>" +
            '<a class="btn btn-block" href="' + esc(b.href) + '"' + ext + ">🛒 Buy Now – " + money(p.price) + "</a>" +
            '<a class="btn btn-outline btn-block" href="shop.html">← Aur products dekho</a>' +
            '<div class="trust">🔒 Safe payment. Koi sawal ho to <a href="index.html#contact" style="color:#C2185B;font-weight:700">contact</a> karo. Refund details ke liye <a href="policies.html" style="color:#C2185B;font-weight:700">policies</a> padho.</div>' +
            "</div>";
        observeNew();
    }

    /* ---------- Contact buttons (home) ---------- */

    function renderContact() {
        var box = document.getElementById("contactExtra");
        if (!box) return;
        var html = "";
        if (validWhatsapp()) {
            html += '<a class="btn" href="https://wa.me/' + STORE.whatsapp + '" target="_blank" rel="noopener">💬 WhatsApp</a>';
        }
        if (STORE.email) {
            html += '<a class="btn btn-outline" href="mailto:' + esc(STORE.email) + '">✉️ Email</a>';
        }
        box.innerHTML = html;
    }

    /* ---------- Init ---------- */

    function init() {
        var y = document.getElementById("year");
        if (y) y.textContent = new Date().getFullYear();

        initNav();
        initTransitions();
        renderFeatured();
        renderShop();
        renderDetail();
        renderContact();
        initReveal();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();
